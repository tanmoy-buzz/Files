#!/bin/bash

# Define log file location
LOG_FILE="$HOME/freeswitch_setup_error.log"

# Function to log error messages
log_error() {
    echo "[ERROR] $1"
    echo "$(date): $1" >> "$LOG_FILE"
}

# Start the setup
echo "Starting setup..."

# Create directories
echo "Creating directories..."
mkdir /opt/odbc 2> /dev/null || log_error "Failed to create /opt/odbc directory"
mkdir -p /var/spool/freeswitch/default 2> /dev/null || log_error "Failed to create /var/spool/freeswitch/default directory"
echo "10% completed"

# Pull Docker image
echo "Pulling Docker image..."
docker pull vedakatta/freeswitch-1.10.7:latest 2> /dev/null || log_error "Failed to pull Docker image"
echo "20% completed"

# Run Docker container
echo "Running Docker container..."
docker run -d --name freeswitch vedakatta/freeswitch-1.10.7:latest 2> /dev/null || log_error "Failed to run Docker container"
echo "30% completed"

# Configuration File Setup
echo "Copying configuration files..."
docker cp freeswitch:/usr/share/freeswitch /usr/share/ 2> /dev/null || log_error "Failed to copy /usr/share/freeswitch"
docker cp freeswitch:/etc/freeswitch /etc/ 2> /dev/null || log_error "Failed to copy /etc/freeswitch"
docker cp freeswitch:/var/log/freeswitch /var/log/ 2> /dev/null || log_error "Failed to copy /var/log/freeswitch"
docker cp freeswitch:/etc/odbc.ini /opt/odbc/ 2> /dev/null || log_error "Failed to copy /etc/odbc.ini"
docker cp freeswitch:/etc/odbcinst.ini /opt/odbc/ 2> /dev/null || log_error "Failed to copy /etc/odbcinst.ini"
echo "60% completed"

# Stop Docker container
echo "Stopping and Removing Docker container..."
docker stop freeswitch 2> /dev/null || log_error "Failed to stop Docker container"
docker container rm -f freeswitch 2> /dev/null || log_error "Failed to remove Docker container"
echo "70% completed"

# Docker-compose up
echo "Starting services with docker-compose..."
docker-compose up -d 2> /dev/null || log_error "Failed to start services with docker-compose"
echo "80% completed"

# SNGREP and fs_cli setup
echo "Setting up SNGREP and fs_cli..."
echo "docker exec -it freeswitch fs_cli" > /usr/bin/fs_cli 2> /dev/null || log_error "Failed to setup fs_cli"
echo "docker exec -it freeswitch sngrep" > /usr/bin/sngrep 2> /dev/null || log_error "Failed to setup sngrep"
chmod +x /usr/bin/fs_cli 2> /dev/null || log_error "Failed to change permissions for fs_cli"
chmod +x /usr/bin/sngrep 2> /dev/null || log_error "Failed to change permissions for sngrep"
echo "100% completed"

echo "Setup completed successfully!"

