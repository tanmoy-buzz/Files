Change freeswitch.xml file for default dialplan file location changes

