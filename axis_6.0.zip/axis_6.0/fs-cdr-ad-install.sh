#!/bin/bash
##################################################################################
# Freeswitch Installation script
# Version: 1.0
# Author: Ganapathi Chidambaram < ganapathi.chidambaram@flexydial.com >
# Supports : Ubuntu-20.04,Debian-11, CentOS, Redhat
###################################################################################
##Redirect the console error and output

exec > ~/cdrd-ad-install.log 2>&1

##load global Environment variable
source /etc/environment

docker login -u vedakatta -p ${DOCKER_TOKEN}

docker pull vedakatta/flexydial-axis-app:latest


cat <<EOT > /etc/default/flexydial-app
FREESWITCH_HOST=${TELEPHONY_HOST}
FLEXYDIAL_DB_NAME=flexydial
FLEXYDIAL_DB_USER=flexydial
FLEXYDIAL_DB_PASS=flexydial
FLEXYDIAL_DB_HOST=${DB_HOST}
FLEXYDIAL_DB_PORT=5432
CRM_DB_NAME=crm
CRM_DB_USER=flexydial
CRM_DB_PASS=flexydial
CRM_DB_HOST=${DB_HOST}
REDIS_HOST=${REDIS_HOST}
EOT

cat <<EOT > /etc/systemd/system/flexydial-cdrd-docker.service
[Unit]
Description=FlexyDial CDR Container
After=docker.service
Requires=docker.service

[Service]
TimeoutStartSec=0
Restart=always
RestartSec=1
#ExecStartPre=/usr/bin/docker pull vedakatta/flexydial-app
ExecStart=/usr/bin/docker run --rm --env-file /etc/default/flexydial-app --name flexydial-cdr vedakatta/flexydial-axis-app:latest python manage.py cdrd
ExecStop=/usr/bin/docker stop flexydial-cdr

[Install]
WantedBy=multi-user.target
EOT

cat <<EOT > /etc/systemd/system/flexydial-autodial-docker.service
[Unit]
Description=FlexyDial AutoDial Container
After=docker.service
Requires=docker.service

[Service]
TimeoutStartSec=0
Restart=always
RestartSec=1
#ExecStartPre=/usr/bin/docker pull vedakatta/flexydial-app
ExecStart=/usr/bin/docker run --rm -v /var/lib/flexydial/media:/var/lib/flexydial/media --env-file /etc/default/flexydial-app --name flexydial-autodial vedakatta/flexydial-axis-app:latest python manage.py autodial
ExecStop=/usr/bin/docker stop flexydial-autodial

[Install]
WantedBy=multi-user.target
EOT

systemctl enable flexydial-cdrd-docker
systemctl start flexydial-cdrd-docker

systemctl enable flexydial-autodial-docker
systemctl start flexydial-autodial-docker
